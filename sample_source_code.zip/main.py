print("Hello from sample source code")
